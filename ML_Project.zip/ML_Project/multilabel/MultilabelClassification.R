install.packages("mlr")
install.packages("rpart")
install.packages("caret")
library(mlr)
library(rpart)
library(caret)


filename = "MultiLabelClassification.R"
filepath=1
filepath = file.choose()
if(filepath!= 1){
  dir = substr(filepath, 1, nchar(filepath)-nchar(filename))
  dir
  setwd(dir)
  
  #loading files as data frames
  trainingData1 = read.csv("/Users/deepikapraneet/Desktop/Deepu/MS/Semester_1_1/Machine Learning/project/multilabel/data/csv/trainingdata.csv",header=FALSE)
  
  labels1 = read.csv("/Users/deepikapraneet/Desktop/Deepu/MS/Semester_1_1/Machine Learning/project/multilabel/data/csv/traininglabel.csv",header=FALSE)
  testData1 = read.csv("/Users/deepikapraneet/Desktop/Deepu/MS/Semester_1_1/Machine Learning/project/multilabel/data/csv/testdata.csv",header=FALSE)
  
  # combining Columns
  combinedcolData=cbind(labels1,trainingData1)
  head(combinedcolData);
  
  #Changing the Label names for Labels
  colnames(combinedcolData)[1:14]=paste("label",seq(1,ncol(labels1)),sep="")
  colnames(combinedcolData)[1:14]
  
  #Convert the 1,0 to TRUE FALSE as target param takes only logical values
  combinedcolData[,1:14]=as.data.frame(lapply(combinedcolData[,1:14],as.logical))
  
  #Labels names
  labelnames=paste("label",seq(1,ncol(labels1)),sep="")
  #creating a task
  combinedcolData.task = makeMultilabelTask(id = "multi", data = combinedcolData, target = labelnames)
  
  
  # Learning is done
  parList=list()
  perfList=c()
  
  maxdepthGrid=c(2)
  cpGrid=c(0.09)
  minSplitValues=(10)
  gridDF = expand.grid(maxdepthGrid,cpGrid,minSplitValues)
  
  # k fold cross validation
  #create k folds
  crossvalGenerateGroups <- function
  
  (
    n, ##<< number of points
    numGroups, ##<< number of groups
    shuffle=TRUE ##<< whether to shuffle the indices before partitioning
  )
  {
    if (numGroups < 2) {
      stop("numGroups should be greater than or equal to 2")
    }
    if (numGroups > n) {
      stop("numGroups should be less than or equal to the number of observations")
    }
    o = if (shuffle) sample(1:n) else 1:n
    
    if (numGroups == n) {
      groups <- as.list(o)
      return(groups)
    }
    
    q = n %/% numGroups   # all groups are size q or (q+1)
    r = n %% numGroups    # r of the groups need to be of size (q+1)
    
    groups = vector("list", numGroups)
    start = 1
    for (group in 1:numGroups) {
      span =  q + (if (group <= r) 1 else 0)
      end = start + span - 1
      groups[[group]] = o[start:end]
      start = end + 1
    }
    return(groups)
    
  }
  k_folds= 5
  flds = crossvalGenerateGroups(nrow(combinedcolData),k_folds)
  
  
  
  fold_preds_perf = list()
  
  
  for(i in 1 :nrow(gridDF))
  {
    
    # Parameter tuning: cp,minsplit,maxdepth
    parList[["cp"]]=gridDF$Var2[i]
    parList[["maxdepth"]]=gridDF$Var1[i]
    parList[["minsplit"]]=gridDF$Var3[i]
    
    #creating a learner
    lrn.br = makeLearner("classif.rpart", predict.type = "prob",par.vals =parList)
    lrn.br = makeMultilabelBinaryRelevanceWrapper(lrn.br)
    lrn.br
    
    
    
    
    # Problem Transformation Method is done
    for(j in 1:k_folds){
      
     #training 
      mod = mlr::train(lrn.br, combinedcolData.task)
      mod = mlr::train(lrn.br, combinedcolData.task, subset = unlist(flds[-j]))
      mod
      
      
      
      # Training is Done
      #prediction 
      pred = predict(mod, task = combinedcolData.task, subset =unlist(flds[j]) )
      #pred = predict(mod, newdata = combinedcolData[400:500,])
      names(as.data.frame(pred))
      
      
      
      # Calculating Performance
      show(performance(pred,measures = list(multilabel.subset01, multilabel.hamloss, multilabel.acc,
                                            multilabel.f1, timepredict)))
      perfList[j] = performance(pred)
      
      
    }                                
    
    
    
    fold_preds_perf[[i]] = mean(perfList)
    
    
    print(fold_preds_perf);
  }
  
  #show minimum error and for which parameter
  minError = which(unlist(fold_preds_perf)==min(unlist(fold_preds_perf)))
  bestParams = gridDF[minError,]
  #show(bestParams)
  
  
  #predictions for test data set
  
  parList[["cp"]]=bestParams$Var2[1]
  parList[["maxdepth"]]=bestParams$Var1[1]
  parList[["minsplit"]]=bestParams$Var3[1]
  
  
  test.lrn.br = makeLearner("classif.rpart", predict.type = "prob",par.vals =parList)
  test.lrn.br = makeMultilabelBinaryRelevanceWrapper(test.lrn.br)
  test.lrn.br
  
  mod1 = mlr::train(test.lrn.br, combinedcolData.task)
  mod1
  
  # predictions
  testDataPred = predict(mod1, newdata = testData1 )
  response=testDataPred$data[,15:ncol(testDataPred$data)]
  
  response[response==TRUE]=1
  response[response==FALSE]=0

  View(response)
  write.table(response,"GopalaMultiLabelClassification.txt",row.names = FALSE, col.names = FALSE, sep = "\t")
  
  
}else
{
  
}



import numpy as np
from fancyimpute import IterativeSVD
dataset1 = np.loadtxt("MissingData1.txt")

expcomplete_SVD = IterativeSVD().complete(dataset1)
#print expcomplete_SVD

np.savetxt('GopalaMissingResult1.txt',expcomplete_SVD,fmt='%f')
#Calculating mean square error
missing_mask = np.random.rand(*expcomplete_SVD.shape)<0.1
#print missing_mask
expdata_missingsvd = expcomplete_SVD.copy()
expdata_missingsvd[missing_mask] = np.nan
expcomplete_missingSVD = IterativeSVD().complete(expdata_missingsvd)
svd_mse = ((expcomplete_missingSVD[missing_mask] - expcomplete_SVD[missing_mask]) ** 2).mean()
#print svd_mse


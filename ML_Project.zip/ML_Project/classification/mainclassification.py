import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics
from sklearn.cross_validation import train_test_split
from fancyimpute import IterativeSVD
dataset1 = np.loadtxt("trainingdata4.csv",delimiter=',')
dataset2 = np.loadtxt("testdata4.csv",delimiter=',')
if(pd.isnull(dataset1).any()):
	expcomplete_SVD = IterativeSVD().complete(dataset1)
	print expcomplete_SVD

	#np.savetxt('trainingdatasvd4.txt',expcomplete_SVD,fmt='%f')
	missing_mask = np.random.rand(*expcomplete_SVD.shape)<0.1
	#print missing_mask
	expdata_missingsvd = expcomplete_SVD.copy()
	expdata_missingsvd[missing_mask] = np.nan
	expcomplete_missingSVD = IterativeSVD().complete(expdata_missingsvd)
	svd_mse = ((expcomplete_missingSVD[missing_mask] - expcomplete_SVD[missing_mask]) ** 2).mean()
	#print svd_mse
	
	trainData = expcomplete_SVD.copy()
else:
	trainData = dataset1.copy()
	
if(pd.isnull(dataset2).any()):
	expcomplete_SVD2 = IterativeSVD().complete(dataset2)
	#print expcomplete_SVD2

	#np.savetxt('trainingdatasvd4.txt',expcomplete_SVD,fmt='%f')
	missing_mask2 = np.random.rand(*expcomplete_SVD2.shape)<0.1
	#print missing_mask
	expdata_missingsvd2 = expcomplete_SVD2.copy()
	expdata_missingsvd2[missing_mask2] = np.nan
	expcomplete_missingSVD2 = IterativeSVD().complete(expdata_missingsvd2)
	svd_mse2 = ((expcomplete_missingSVD2[missing_mask2] - expcomplete_SVD2[missing_mask2]) ** 2).mean()
	#print svd_mse
	
	testData = expcomplete_SVD2.copy()
else:
	testData = dataset2.copy()


#training labels
trainLabels = np.loadtxt("TrainLabel4.txt")

X_train,X_test,Y_train,Y_test= train_test_split(trainData,trainLabels,test_size=0.3,random_state=1)
clf = RandomForestClassifier(n_estimators=300)
clf.fit(X_train,Y_train)

Y_predict = clf.predict(X_test)

#print str(metrics.accuracy_score(Y_test, Y_predict))
#print str(clf.score(X_test,Y_test))
clf.fit(trainData, trainLabels) 

testLabel=clf.predict(testData)

np.savetxt('GopalaClassificationResult4.txt',testLabel, fmt='%d')
